const HomePage = () => {
  return (
    <div>
      <h1>Something Good is Comming</h1>
      <h2>Don&apos;t miss it</h2>
      <p>all good things takes time</p>
      <p>it&apos;s really does</p>
    </div>
  );
};

export default HomePage;
